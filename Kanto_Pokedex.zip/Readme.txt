Main Project File that works in Terminal is 'Kanto Pokedex'.
For GUI functionality the file 'KANTO_POKEDEX' was created or duplicated.
The rest of the important files include 'PokeDex', 'Open_Pokedex', 'PokeDex_details', 'pokemondetails' and 'Get_details'.

1. Kanto Pokedex
2. KANTO_POKEDEX
3. PokeDex
4. Open_PokeDex(currently not in use)
5. PokeDex_details
6. pokemondetails
7. Get_Details