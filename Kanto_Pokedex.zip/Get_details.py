# Harshit Goyal
import KANTO_POKEDEX
import Open_PokeDex
import pokemondetails

def getpokedex_details():

    print('To access info about Pokemon\n <A> Enter Pokemon name\n <B> Enter Pokemon ID number')

    pokemon_input=input()

    #HARSHATH
    if pokemon_input=='Back' or pokemon_input=='BACK' or pokemon_input=='back':
        
        KANTO_POKEDEX.execution_codes()


    elif pokemon_input=='Help'or pokemon_input== 'help' or pokemon_input == 'HELP':
        print(' If you would like to get help in pokemon names or their IDs, Please type \'pINDEX\' ')
        
        print('Press Enter to continue')

        nonresponsive=input()

        getpokedex_details()

    

    elif pokemon_input=='pINDEX':
        
        Open_PokeDex.pokedex_title()
        
        Open_PokeDex.pokedex_table_row_headings()
        
        Open_PokeDex.pokedex_table_contents()
        
        print('Press Enter to continue')

        nonresponsive=input()

        getpokedex_details()

    #Harshit from here

    elif pokemon_input=='A':

        print('Enter Pokemon Name: (Please Type the first alphabet in uppercase) ')

        name_input=input()

        pokemondetails.pokemon_details_name(name_input)


    elif pokemon_input=='B':

        print('Enter Pokemon ID: ')

        ID_input=input()

        pokemondetails.pokemon_details_ID(ID_input)


    #if pokemon_input!='A' and pokemon_input!='B':

    else:

        print("Please enter either A or B")

        #edit by Harshath for main project from here

        print('Press Enter to continue')

        nonresponsive=input()

        getpokedex_details()

#end