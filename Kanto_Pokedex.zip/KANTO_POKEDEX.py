 
#Kanto_Pokedex

#This Bot is a piece of entertainment that will allow its users to access data on pokemon that are based on Kanto region(for now).

#This projects aims to create something that is a hybrid of both a game and a bot(sort of) but it mostly servers like a chatbot.

'''
The Team members working on this project are mentioned below:

    V Harshath

    Harshit Goyal

    Mradul Bhateley

    Chirag Verma

'''

#---------------------------------------------------------------------------------- PROJECT STARTS HERE GUYS -----------------------------------------------------------------------#

import sys

import PokeDex

import pokemondetails

#import PokeDex_details

def initial_display():

    print("\nKanto_Pokedex\n")
    
    print("Welcome Pokemon Lovers!\n")


# The first function to be displayed to the User.

def welcome_user():

    print('''To proceed, type the alphabet associated with the options below -
           
           <A> Search for Pokemon 
           <B> Open Pokedex index
           <C> Open Detailed Pokedex
           <D> Exit

          ''')


# Some predefined things for later use(these are important I guess)

option_input=''

user_response=''

user_choice=''

name_input=''

ID_input=''


# option_out function takes the option input given by the User and then executes the function corresponding to the value of the option.

def option_out(option_input):

    if option_input == 'A':

        search_pokemon()


    if option_input == 'B':

        print('\nHere\'s your Pokedex\n')

        get_PokeDex()


    if option_input == 'C':

        #Get_details.getpokedex_details()

        getPokeDex_info()


    if option_input == 'D':

        print('\nThank you for using \'Kanto Pokedex\'!\n' )
        
        sys.exit()


    if option_input != 'A' or option_input != 'B' or option_input != 'C' or option_input != 'D':

        print('Please enter a valid option.')

        print('Press Enter to continue')

        nonresponsive=input()

        #welcome_user()

        #option_input=input()

        #option_out(option_input)

        execution_codes()


# execution_codes, not in use for now

def execution_codes():

    welcome_user()

    option_input=(input())

    option_out(option_input)


# getPokeDex_info is basically used to call the detailed pokedex function.

def getPokeDex_info():

    import Get_details

    Get_details.getpokedex_details()

    print('Press Enter to coninue')

    nonresponsive=input()

    print('Would you like to explore any other options? Type Yes or No')

    user_response=input().lower()
            
    
    if user_response=='yes' or user_response=='YES' or user_response=='Yes':

        welcome_user()

        option_input=input()

        option_out(option_input)
            

    if user_response=='no' or user_response=='NO' or user_response=='No':

        print('\nThank you for using \'Kanto Pokedex\'!\n' )

        sys.exit()

    
    else:

        print('Invalid Response')

        print('\nPress Enter to coninue')

        nonresponsive=input()

        choice_response()


# Miscellaneous Functions I defined maybe for later uses or not( and they were used ;) )


#choice_response

def choice_response():

    print('Would you like to explore any other options? Type Yes or No')

    user_response=input()

    
    if user_response=='yes' or user_response=='YES' or user_response=='Yes':

        welcome_user()

        option_input=(input())

        option_out(option_input)
                
    
    if user_response=='no' or user_response=='NO' or user_response=='No':

        print('\nThank you for using \'Kanto Pokedex\'!\n' )

        sys.exit()


#part by V Harshath and Chirag -


# get_PokeDex function opens the Pokedex when called.

def get_PokeDex():

    print ('\nPokeDex_Kanto_Region')

    print ('\nNdex   Pokémon')

    i=0
    
    j=0
    
    PDex=[]
    
    
    for i in PokeDex.Pokedex:
    
        a=('\n#{} - {}'.format(i,PokeDex.Pokedex[i]))
    
        PDex.append(a)
    
    
    def open_pokemons():
    
        for j in range(0,151):
    
            A=PDex.__getitem__(j)
    
            print(A)
    
            j+=1
    
    open_pokemons()
    
    print('\nPress Enter to coninue')

    nonresponsive=input()

    print('Would you like to explore any other options? Type Yes or No')        
    
    user_response=input()
            
    
    if user_response=='yes' or user_response=='YES' or user_response=='Yes' :

        welcome_user()

        option_input=input()

        option_out(option_input)
            
    
    if user_response=='no' or user_response=='NO' or user_response=='No' :

        print('\nThank you for using \'Kanto Pokedex\'!\n' )

        sys.exit()

    
    else:

        print('Invalid Response')

        print('\nPress Enter to coninue')

        nonresponsive=input()

        choice_response()


#part by Mradul and V Harshath -


# search_pokemon function allows the user to search pokemon by their name or ID no.

def search_pokemon():

    print("\nTo Search for a pokemon:\n")

    print("<A>Search by pokemon name\n<B>Search by pokemon ID Number\n\n(Type A or B and Press enter)\n")
    
    User_input=input()
    

    if User_input=='Back'or User_input=='back'or User_input=='BACK':
    
        execution_codes()
    
    
    if User_input!="A" and User_input!="B":

        print("Please type either A or B")

        print('\nPress Enter to coninue')

        nonresponsive=input()

        search_pokemon()

    
    #Search by pokemon name method
    
    if(User_input=="A"):

        def name_search():

            print("Enter the name of the pokemon: (Please Type the first alphabet in uppercase) ")

            name_input = input()


            if name_input =='BACK' or name_input=='Back' or name_input=='back':
                
                search_pokemon()


            if name_input not in PokeDex.Pokedex.values():

                print('Please enter a pokemon name from only Kanto Region!')

                print('\nPress Enter to coninue')

                nonresponsive=input()

                name_search()

            
            if name_input in PokeDex.Pokedex.values():

                print('\n{}\'s ID Number in the Pokedex is {}\n'.format(name_input,list(PokeDex.Pokedex.keys())[list(PokeDex.Pokedex.values()).index(name_input)]))

                print('Would like to access details on {}? Type Yes or No'.format(name_input))
            
                user_choice=input()
            
                
                if user_choice=='yes' or user_choice=='YES' or user_choice=='Yes':

                    print('\nloading Pokedex info on {}'.format(name_input))
                
                    import pokemondetails

                    pokemondetails.pokemon_details_name(name_input)
                
                    print('Press Enter to coninue')

                    nonresponsive=input()
                
                    print('Would you like to explore any other options? Type Yes or No')

                    user_response=input()

                    
                    if user_response=='yes' or user_response=='YES' or user_response=='Yes':

                        welcome_user()

                        option_input=(input())

                        option_out(option_input)
                
                    
                    if user_response=='no' or user_response=='NO' or user_response=='No':

                        print('\nThank you for using \'Kanto Pokedex\'!\n' )

                        sys.exit()

                    
                    if user_response!='no' or user_response!='NO' or user_response!='No' or user_response!='yes' or user_response=='YES' or user_response=='Yes':

                        print('Invalid Response')

                        print('\nPress Enter to coninue')

                        nonresponsive=input()

                        choice_response()
           

                if user_choice=='no' or user_choice=='NO' or user_choice=='No':

                    print('Would you like to explore any other options? Type Yes or No')

                    user_response=input()

                    
                    if user_response=='yes' or user_response=='YES' or user_response=='Yes':

                        welcome_user()

                        option_input=(input())

                        option_out(option_input)
                
                    
                    if user_response=='no' or user_response=='NO' or user_response=='No':

                        print('\nThank you for using \'Kanto Pokedex\'!\n' )

                        sys.exit()

                    
                    if user_response!='no' or user_response!='NO' or user_response!='No' or user_response!='yes' or user_response=='YES' or user_response=='Yes':

                        print('Invalid Response')

                        print('\nPress Enter to coninue')

                        nonresponsive=input()

                        choice_response()
            
                
                if user_choice!='no' or user_choice!='NO' or user_choice!='No' or user_choice!='yes' or user_choice=='YES' or user_choice=='Yes':

                    print('Invalid Response')

                    print('\nPress Enter to coninue')

                    nonresponsive=input()

                    choice_response()
        
        name_search()

    #Search by pokemon ID Number
    
    if User_input=='B':

        def ID_search():

            print("Enter ID Number of the pokemon: (Please Type the ID Number upto 3 digits ) ")

            ID_input=input()

            #if int(ID_input)<1 or int(ID_input)>151:

            
            if ID_input=='Back' or ID_input=='BACK' or ID_input=='back':
                
                search_pokemon()


            if ID_input not in PokeDex.Pokedex.keys():

                print("Please enter a valid ID number!")

                print('\nPress Enter to coninue')

                nonresponsive=input()
                
                ID_search()


            
            if ID_input in PokeDex.Pokedex.keys():

                print('The Pokemon with the ID Number {} is {}'.format(ID_input,PokeDex.Pokedex[ID_input]))

                print('\nPress Enter to coninue')

                nonresponsive=input()
            
                print('Would like to access details on {}? Type Yes or No'.format(PokeDex.Pokedex[ID_input]))
            
                user_choice=input()
            
                
                if user_choice=='yes' or user_choice=='YES' or user_choice=='Yes':

                    print('loading Pokedex info on {}'.format(PokeDex.Pokedex[ID_input]))
                
                    import pokemondetails

                    pokemondetails.pokemon_details_ID(ID_input)

                    print('Press Enter to coninue')

                    nonresponsive=input()
                
                    print('Would you like to explore any other options? Type Yes or No')

                    user_response=input()

                    
                    if user_response=='yes' or user_response=='YES' or user_response=='Yes':

                        welcome_user()

                        option_input=(input())

                        option_out(option_input)
                
                    
                    if user_response=='no' or user_response=='NO' or user_response=='No':

                        print('\nThank you for using \'Kanto Pokedex\'!\n' )

                        sys.exit()

                    
                    else:

                        print('Invalid Response')

                        print('\nPress Enter to coninue')

                        nonresponsive=input()

                        choice_response()
            
                
                if user_choice=='no' or user_choice=='NO' or user_choice=='No':

                    print('Would you like to explore any other options? Type Yes or No')
            
                    user_response=input()
            
                    
                    if user_response=='yes' or user_response=='YES' or user_response=='Yes':

                        welcome_user()

                        option_input=input()

                        option_out(option_input)
            
                    if user_response=='no' or user_response=='NO' or user_response=='No':

                        print('\nThank you for using \'Kanto Pokedex\'!\n' )

                        sys.exit()

                    else:

                        print('Invalid Response')

                        print('\nPress Enter to coninue')

                        nonresponsive=input()

                        choice_response()

                else:

                    print('Invalid Response')

                    print('\nPress Enter to coninue')

                    nonresponsive=input()

                    choice_response()

        ID_search()

#execution_lines

#initial_display()

#execution_codes()

# --------------------------------------------------------------------------- CODE LINE PROJECT NOW COMPLETE ---------------------------------------------------------------------- #
# ------------------------------------------------------------------------------- NOW FOR THE GUI PROJECT ------------------------------------------------------------------------- #