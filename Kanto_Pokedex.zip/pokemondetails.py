#chirag and harshit
import PokeDex_details
name_input=''
ID_input=''

def pokemon_details_name(name_input):
    if name_input=='Bulbasaur':
        print(PokeDex_details._P001)
    elif name_input=='Ivysaur':
        print(PokeDex_details._P002)
    elif name_input=='Venusaur':
        print(PokeDex_details._P003)
    elif name_input=='Charmander':
        print(PokeDex_details._P004)
    elif name_input=='Charmeleon':
        print(PokeDex_details._P005)
    elif name_input=='Charizard':
        print(PokeDex_details._P006)
    elif name_input=='Squirtle':
        print(PokeDex_details._P007)
    elif name_input=='Wartortle':
        print(PokeDex_details._P008)
    elif name_input=='Blastoise':
        print(PokeDex_details._P009)
    elif name_input=='Caterpie':
        print(PokeDex_details._P010)
    elif name_input=='Metapod':
        print(PokeDex_details._P011)
    elif name_input=='Butterfree':
        print(PokeDex_details._P012)
    elif name_input=='Weedle':
        print(PokeDex_details._P013)
    elif name_input=='Kakuna':
        print(PokeDex_details._P014)
    elif name_input=='Beedrill':
        print(PokeDex_details._P015)
    elif name_input=='Pidgey':
        print(PokeDex_details._P016)
    elif name_input=='Pidgeotto':
        print(PokeDex_details._P017)
    elif name_input=='Pidgeot':
        print(PokeDex_details._P018)
    elif name_input=='Rattata':
        print(PokeDex_details._P019)
    elif name_input=='Raticate':
        print(PokeDex_details._P020)
    elif name_input=='Spearow':
        print(PokeDex_details._P021)
    elif name_input=='Fearow':
        print(PokeDex_details._P022)
    elif name_input=='Ekans':
        print(PokeDex_details._P023)
    elif name_input=='Arbok':
        print(PokeDex_details._P024)
    elif name_input=='Pikachu':
        print(PokeDex_details._P025)
    elif name_input=='Raichu':
        print(PokeDex_details._P026)
    elif name_input=='Sandshrew':
        print(PokeDex_details._P027)
    elif name_input=='Sandslash':
        print(PokeDex_details._P028)
    elif name_input=='Nidoran':
        print(PokeDex_details._P029)
    elif name_input=='Nidorina':
        print(PokeDex_details._P030)
    elif name_input=='Nidoqueen':
        print(PokeDex_details._P031)
    elif name_input=='Nidoran':
        print(PokeDex_details._P032)
    elif name_input=='Nidorino':
        print(PokeDex_details._P033)
    elif name_input=='Nidoking':
        print(PokeDex_details._P034)
    elif name_input=='Clefairy':
        print(PokeDex_details._P035)
    elif name_input=='Clefable':
        print(PokeDex_details._P036) 
    elif name_input=='Vulpix':
        print(PokeDex_details._P037)
    elif name_input=='Ninetales':
        print(PokeDex_details._P038)
    elif name_input=='Jigglypuff':
        print(PokeDex_details._P039)
    elif name_input=='Wigglytuff':
        print(PokeDex_details._P040)
    elif name_input=='Zubat':
        print(PokeDex_details._P041)
    elif name_input=='Golbat':
        print(PokeDex_details._P042)
    elif name_input=='Oddish':
        print(PokeDex_details._P043)
    elif name_input=='Gloom':
        print(PokeDex_details._P044)
    elif name_input=='Vileplume':
        print(PokeDex_details._P045)
    elif name_input=='Paras':
        print(PokeDex_details._P046)
    elif name_input=='Parasect':
        print(PokeDex_details._P047)
    elif name_input=='Venonat':
        print(PokeDex_details._P048)
    elif name_input=='Venomoth':
        print(PokeDex_details._P049)
    elif name_input=='Diglett':
        print(PokeDex_details._P050)
    elif name_input=='Dugtrio':
        print(PokeDex_details._P051)
    elif name_input=='Meowth':
        print(PokeDex_details._P052)
    elif name_input=='Persian':
        print(PokeDex_details._P053)
    elif name_input=='Psyduck':
        print(PokeDex_details._P054)
    elif name_input=='Golduck':
        print(PokeDex_details._P055)
    elif name_input=='Mankey':
        print(PokeDex_details._P056)
    elif name_input=='Primeape':
       print(PokeDex_details._P057)
    elif name_input=='Growlithe':
        print(PokeDex_details._P058)
    elif name_input=='Arcanine':
        print(PokeDex_details._P059)
    elif name_input=='Poliwag':
        print(PokeDex_details._P060)
    elif name_input=='Poliwhirl':
        print(PokeDex_details._P061)
    elif name_input=='Poliwrath':
        print(PokeDex_details._P063)
    elif name_input=='Abra':
        print(PokeDex_details._P063)
    elif name_input=='Kadabra':
        print(PokeDex_details._P064)
    elif name_input=='Alakazam':
        print(PokeDex_details._P065)
    elif name_input=='Machop':
        print(PokeDex_details._P066)
    elif name_input=='Machoke':
        print(PokeDex_details._P067)
    elif name_input=='Machamp':
        print(PokeDex_details._P068)
    elif name_input=='Bellsprout':
        print(PokeDex_details._P069)
    elif name_input=='Weepinball':
        print(PokeDex_details._P070)
    elif name_input=='Victreebell':
        print(PokeDex_details._P071)
    elif name_input=='Tentacool':
        print(PokeDex_details._P072)
    elif name_input=='Tentacruel':
        print(PokeDex_details._P073)
    elif name_input=='Geodude':
        print(PokeDex_details._P074)
    elif name_input=='Graveler':
        print(PokeDex_details._P075)
    elif name_input=='Golem':
        print(PokeDex_details._P076)
    elif name_input=='Ponyta':
        print(PokeDex_details._P077)
    elif name_input=='Rapidash':
        print(PokeDex_details._P078)
    elif name_input=='Slowpoke':
        print(PokeDex_details._P079)
    elif name_input=='Slowbro':
        print(PokeDex_details._P080)
    elif name_input=='Magnemite':
        print(PokeDex_details._P081)
    elif name_input=='Magneton':
        print(PokeDex_details._P082) 
    elif name_input=='Farfetchd':
        print(PokeDex_details._P083) 
    elif name_input=='Doduo':
        print(PokeDex_details._P084)
    elif name_input=='Dodrio': 
        print(PokeDex_details._P085)
    elif name_input=='Seel':
        print(PokeDex_details._P086)
    elif name_input=='Dewgong':
        print(PokeDex_details._P087)
    elif name_input=='Grimer':
        print(PokeDex_details._P088)
    elif name_input=='Muk':
        print(PokeDex_details._P089)
    elif name_input=='Shellder':
        print(PokeDex_details._P090)
    elif name_input=='Cloyster':
        print(PokeDex_details._P091)
    elif name_input=='Gastly':
        print(PokeDex_details._P092)
    elif name_input=='Haunter':
        print(PokeDex_details._P093)
    elif name_input=='Gengar':
        print(PokeDex_details._P094)
    elif name_input=='Onix':
        print(PokeDex_details._P095)
    elif name_input=='Drowzee':
        print(PokeDex_details._P096)
    elif name_input=='Hypno':
        print(PokeDex_details._P097)
    elif name_input=='Krabby':
        print(PokeDex_details._P098)
    elif name_input=='Kingler':
        print(PokeDex_details._P099)
    elif name_input=='Voltorb': 
        print(PokeDex_details._P100)
    elif name_input=='Electrode':
        print(PokeDex_details._P101)
    elif name_input=='Exeggcute':
        print(PokeDex_details._P102)
    elif name_input=='Exeguttor':
        print(PokeDex_details._P103)
    elif name_input=='Cubone':
        print(PokeDex_details._P104)
    elif name_input=='Marowak':
        print(PokeDex_details._P105)
    elif name_input=='Hitmonlee':
        print(PokeDex_details._P106)
    elif name_input=='Hitmoncham':
        print(PokeDex_details._P107)
    elif name_input=='Lickitung':
        print(PokeDex_details._P108)
    elif name_input=='Koffing':
        print(PokeDex_details._P109)
    elif name_input=='Weezing':
        print(PokeDex_details._P110)
    elif name_input=='Rhyhorn':
        print(PokeDex_details._P111)
    elif name_input=='Rhydon':
        print(PokeDex_details._P112)
    elif name_input=='Chansey':
        print(PokeDex_details._P113)
    elif name_input=='Tangela':
        print(PokeDex_details._P114)
    elif name_input=='Kangaskhan':
        print(PokeDex_details._P115)
    elif name_input=='Horsea':
        print(PokeDex_details._P116)
    elif name_input=='Seadra':
        print(PokeDex_details._P117)
    elif name_input=='Goldeen':
        print(PokeDex_details._P118)
    elif name_input=='Seaking':
        print(PokeDex_details._P119)
    elif name_input=='Staryu':
        print(PokeDex_details._P120)
    elif name_input=='Starmie':
        print(PokeDex_details._P121)
    elif name_input=='Mr.Mime':
        print(PokeDex_details._P122)
    elif name_input=='Scyther':
        print(PokeDex_details._P123)
    elif name_input=='Jynx':
        print(PokeDex_details._P124)
    elif name_input=='Electabuzz':
        print(PokeDex_details._P125)
    elif name_input=='Magmar':
        print(PokeDex_details._P126)
    elif name_input=='Pinsir':
        print(PokeDex_details._P127)
    elif name_input=='Tauros':
        print(PokeDex_details._P128)
    elif name_input=='Magikarp':
        print(PokeDex_details._P129)
    elif name_input=='Gyarados':
        print(PokeDex_details._P130)
    elif name_input=='Lapras':
        print(PokeDex_details._P131)
    elif name_input=='Ditto':
        print(PokeDex_details._P132)
    elif name_input=='Eevee':
        print(PokeDex_details._P133)
    elif name_input=='Vaporeon':
        print(PokeDex_details._P134)
    elif name_input=='Jolteon':
        print(PokeDex_details._P135)
    elif name_input=='Flareon':
        print(PokeDex_details._P136)
    elif name_input=='Porygon':
        print(PokeDex_details._P137)
    elif name_input=='Omanyte':
        print(PokeDex_details._P138)
    elif name_input=='Omastar':
        print(PokeDex_details._P139)
    elif name_input=='Kabuto':
        print(PokeDex_details._P140)
    elif name_input=='Kabutops':
        print(PokeDex_details._P141)
    elif name_input=='Aerodactyl':
        print(PokeDex_details._P142)
    elif name_input=='Snorlax':
        print(PokeDex_details._P143)
    elif name_input=='Articuno':
        print(PokeDex_details._P144)
    elif name_input=='Zapdos':
        print(PokeDex_details._P145)
    elif name_input=='Moltres':
        print(PokeDex_details._P146)
    elif name_input=='Dratini':
        print(PokeDex_details._P147)
    elif name_input=='Dragonair':
        print(PokeDex_details._P148)
    elif name_input=='Dragonite':
        print(PokeDex_details._P149)
    elif name_input=='Mewtwo':
        print(PokeDex_details._P150)
    elif name_input=='Mew':
        print(PokeDex_details._P151)
    else:
        print("Please enter only Pokemon Name")
        print('\nPress Enter to continue')
        nonresponsive=input()
        print('Enter Pokemon Name: ')
        name_input=input()
        pokemon_details_name(name_input)



def pokemon_details_ID(ID_input):
    if ID_input=='001' or ID_input=='01'or ID_input=='1':
        print(PokeDex_details._P001)
    elif ID_input=='002'or ID_input=='02'or ID_input=='2':
        print(PokeDex_details._P002)
    elif ID_input=='003'or ID_input=='03'or ID_input=='3':
        print(PokeDex_details._P003)
    elif ID_input=='004'or ID_input=='04'or ID_input=='4':
        print(PokeDex_details._P004)
    elif ID_input=='005'or ID_input=='05'or ID_input=='5':
        print(PokeDex_details._P005)
    elif ID_input=='006'or ID_input=='06'or ID_input=='6':
        print(PokeDex_details._P006)
    elif ID_input=='007'or ID_input=='07'or ID_input=='7':
        print(PokeDex_details._P007)
    elif ID_input=='008'or ID_input=='08'or ID_input=='8':
        print(PokeDex_details._P008)
    elif ID_input=='009'or ID_input=='09'or ID_input=='9':
        print(PokeDex_details._P009)
    elif ID_input=='010'or ID_input=='10':
        print(PokeDex_details._P010)
    elif ID_input=='011'or ID_input=='11':
        print(PokeDex_details._P011)
    elif ID_input=='012'or ID_input=='12':
        print(PokeDex_details._P012)
    elif ID_input=='013'or ID_input=='13':
        print(PokeDex_details._P013)
    elif ID_input=='014'or ID_input=='14':
        print(PokeDex_details._P014)
    elif ID_input=='015'or ID_input=='15':
        print(PokeDex_details._P015)
    elif ID_input=='016'or ID_input=='16':
        print(PokeDex_details._P016)
    elif ID_input=='017'or ID_input=='17':
        print(PokeDex_details._P017)
    elif ID_input=='018'or ID_input=='18':
        print(PokeDex_details._P018)
    elif ID_input=='019'or ID_input=='19':
        print(PokeDex_details._P019)
    elif ID_input=='020'or ID_input=='20':
        print(PokeDex_details._P020)
    elif ID_input=='021'or ID_input=='21':
        print(PokeDex_details._P021)
    elif ID_input=='022'or ID_input=='22':
        print(PokeDex_details._P022)
    elif ID_input=='023'or ID_input=='23':
        print(PokeDex_details._P023)
    elif ID_input=='024'or ID_input=='24':
        print(PokeDex_details._P024)
    elif ID_input=='025'or ID_input=='25':
        print(PokeDex_details._P025)
    elif ID_input=='026'or ID_input=='26':
        print(PokeDex_details._P026)
    elif ID_input=='027'or ID_input=='27':
        print(PokeDex_details._P027)
    elif ID_input=='028'or ID_input=='28':
        print(PokeDex_details._P028)
    elif ID_input=='029'or ID_input=='29':
        print(PokeDex_details._P029)
    elif ID_input=='030'or ID_input=='30':
        print(PokeDex_details._P030)
    elif ID_input=='031'or ID_input=='31':
        print(PokeDex_details._P031)
    elif ID_input=='032'or ID_input=='32':
        print(PokeDex_details._P032)
    elif ID_input=='033'or ID_input=='33':
        print(PokeDex_details._P033)
    elif ID_input=='034'or ID_input=='34':
        print(PokeDex_details._P034)
    elif ID_input=='035'or ID_input=='35':
        print(PokeDex_details._P035)
    elif ID_input=='036'or ID_input=='36':
        print(PokeDex_details._P036) 
    elif ID_input=='037'or ID_input=='37':
        print(PokeDex_details._P037)
    elif ID_input=='038'or ID_input=='38':
        print(PokeDex_details._P038)
    elif ID_input=='030'or ID_input=='39':
        print(PokeDex_details._P039)
    elif ID_input=='040'or ID_input=='40':
        print(PokeDex_details._P040)
    elif ID_input=='041'or ID_input=='41':
        print(PokeDex_details._P041)
    elif ID_input=='042'or ID_input=='42':
        print(PokeDex_details._P042)
    elif ID_input=='043'or ID_input=='43':
        print(PokeDex_details._P043)
    elif ID_input=='044'or ID_input=='44':
        print(PokeDex_details._P044)
    elif ID_input=='045'or ID_input=='45':
        print(PokeDex_details._P045)
    elif ID_input=='046'or ID_input=='46':
        print(PokeDex_details._P046)
    elif ID_input=='047'or ID_input=='47':
        print(PokeDex_details._P047)
    elif ID_input=='048'or ID_input=='48':
        print(PokeDex_details._P048)
    elif ID_input=='049'or ID_input=='49':
        print(PokeDex_details._P049)
    elif ID_input=='050'or ID_input=='50':
        print(PokeDex_details._P050)
    elif ID_input=='051'or ID_input=='51':
        print(PokeDex_details._P051)
    elif ID_input=='052'or ID_input=='52':
        print(PokeDex_details._P052)
    elif ID_input=='053'or ID_input=='53':
        print(PokeDex_details._P053)
    elif ID_input=='054'or ID_input=='54':
        print(PokeDex_details._P054)
    elif ID_input=='055'or ID_input=='55':
        print(PokeDex_details._P055)
    elif ID_input=='056'or ID_input=='56':
        print(PokeDex_details._P056)
    elif ID_input=='057'or ID_input=='57':
       print(PokeDex_details._P057)
    elif ID_input=='058'or ID_input=='58':
        print(PokeDex_details._P058)
    elif ID_input=='059'or ID_input=='59':
        print(PokeDex_details._P059)
    elif ID_input=='060'or ID_input=='60':
        print(PokeDex_details._P060)
    elif ID_input=='061'or ID_input=='61':
        print(PokeDex_details._P061)
    elif ID_input=='062'or ID_input=='62':
        print(PokeDex_details._P063)
    elif ID_input=='063'or ID_input=='63':
        print(PokeDex_details._P063)
    elif ID_input=='064'or ID_input=='64':
        print(PokeDex_details._P064)
    elif ID_input=='065'or ID_input=='65':
        print(PokeDex_details._P065)
    elif ID_input=='066'or ID_input=='66':
        print(PokeDex_details._P066)
    elif ID_input=='067'or ID_input=='67':
        print(PokeDex_details._P067)
    elif ID_input=='068'or ID_input=='68':
        print(PokeDex_details._P068)
    elif ID_input=='069'or ID_input=='69':
        print(PokeDex_details._P069)
    elif ID_input=='070'or ID_input=='70':
        print(PokeDex_details._P070)
    elif ID_input=='071'or ID_input=='71':
        print(PokeDex_details._P071)
    elif ID_input=='072'or ID_input=='72':
        print(PokeDex_details._P072)
    elif ID_input=='073'or ID_input=='73':
        print(PokeDex_details._P073)
    elif ID_input=='074'or ID_input=='74':
        print(PokeDex_details._P074)
    elif ID_input=='075'or ID_input=='75':
        print(PokeDex_details._P075)
    elif ID_input=='076'or ID_input=='76':
        print(PokeDex_details._P076)
    elif ID_input=='077'or ID_input=='77':
        print(PokeDex_details._P077)
    elif ID_input=='078'or ID_input=='78':
        print(PokeDex_details._P078)
    elif ID_input=='079'or ID_input=='79':
        print(PokeDex_details._P079)
    elif ID_input=='080'or ID_input=='80':
        print(PokeDex_details._P080)
    elif ID_input=='081'or ID_input=='81':
        print(PokeDex_details._P081)
    elif ID_input=='082'or ID_input=='82':
        print(PokeDex_details._P082) 
    elif ID_input=='083'or ID_input=='83':
        print(PokeDex_details._P083) 
    elif ID_input=='084'or ID_input=='84':
        print(PokeDex_details._P084)
    elif ID_input=='85'or ID_input=='85': 
        print(PokeDex_details._P085)
    elif ID_input=='086'or ID_input=='86':
        print(PokeDex_details._P086)
    elif ID_input=='087'or ID_input=='87':
        print(PokeDex_details._P087)
    elif ID_input=='088'or ID_input=='88':
        print(PokeDex_details._P088)
    elif ID_input=='089'or ID_input=='89':
        print(PokeDex_details._P089)
    elif ID_input=='090'or ID_input=='90':
        print(PokeDex_details._P090)
    elif ID_input=='091'or ID_input=='91':
        print(PokeDex_details._P091)
    elif ID_input=='092'or ID_input=='92':
        print(PokeDex_details._P092)
    elif ID_input=='093'or ID_input=='93':
        print(PokeDex_details._P093)
    elif ID_input=='094'or ID_input=='94':
        print(PokeDex_details._P094)
    elif ID_input=='095'or ID_input=='95':
        print(PokeDex_details._P095)
    elif ID_input=='096'or ID_input=='96':
        print(PokeDex_details._P096)
    elif ID_input=='097'or ID_input=='97':
        print(PokeDex_details._P097)
    elif ID_input=='098'or ID_input=='98':
        print(PokeDex_details._P098)
    elif ID_input=='099'or ID_input=='99':
        print(PokeDex_details._P099)
    elif ID_input=='100': 
        print(PokeDex_details._P100)
    elif ID_input=='101':
        print(PokeDex_details._P101)
    elif ID_input=='102':
        print(PokeDex_details._P102)
    elif ID_input=='103':
        print(PokeDex_details._P103)
    elif ID_input=='104':
        print(PokeDex_details._P104)
    elif ID_input=='105':
        print(PokeDex_details._P105)
    elif ID_input=='106':
        print(PokeDex_details._P106)
    elif ID_input=='107':
        print(PokeDex_details._P107)
    elif ID_input=='108':
        print(PokeDex_details._P108)
    elif ID_input=='109':
        print(PokeDex_details._P109)
    elif ID_input=='110':
        print(PokeDex_details._P110)
    elif ID_input=='111':
        print(PokeDex_details._P111)
    elif ID_input=='112':
        print(PokeDex_details._P112)
    elif ID_input=='113':
        print(PokeDex_details._P113)
    elif ID_input=='114':
        print(PokeDex_details._P114)
    elif ID_input=='115':
        print(PokeDex_details._P115)
    elif ID_input=='116':
        print(PokeDex_details._P116)
    elif ID_input=='117':
        print(PokeDex_details._P117)
    elif ID_input=='118':
        print(PokeDex_details._P118)
    elif ID_input=='119':
        print(PokeDex_details._P119)
    elif ID_input=='120':
        print(PokeDex_details._P120)
    elif ID_input=='121':
        print(PokeDex_details._P121)
    elif ID_input=='122':
        print(PokeDex_details._P122)
    elif ID_input=='123':
        print(PokeDex_details._P123)
    elif ID_input=='124':
        print(PokeDex_details._P124)
    elif ID_input=='125':
        print(PokeDex_details._P125)
    elif ID_input=='126':
        print(PokeDex_details._P126)
    elif ID_input=='127':
        print(PokeDex_details._P127)
    elif ID_input=='128':
        print(PokeDex_details._P128)
    elif ID_input=='129':
        print(PokeDex_details._P129)
    elif ID_input=='130':
        print(PokeDex_details._P130)
    elif ID_input=='131':
        print(PokeDex_details._P131)
    elif ID_input=='132':
        print(PokeDex_details._P132)
    elif ID_input=='133':
        print(PokeDex_details._P133)
    elif ID_input=='134':
        print(PokeDex_details._P134)
    elif ID_input=='135':
        print(PokeDex_details._P135)
    elif ID_input=='136':
        print(PokeDex_details._P136)
    elif ID_input=='137':
        print(PokeDex_details._P137)
    elif ID_input=='138':
        print(PokeDex_details._P138)
    elif ID_input=='139':
        print(PokeDex_details._P139)
    elif ID_input=='140':
        print(PokeDex_details._P140)
    elif ID_input=='141':
        print(PokeDex_details._P141)
    elif ID_input=='142':
        print(PokeDex_details._P142)
    elif ID_input=='143':
        print(PokeDex_details._P143)
    elif ID_input=='144':
        print(PokeDex_details._P144)
    elif ID_input=='145':
        print(PokeDex_details._P145)
    elif ID_input=='146':
        print(PokeDex_details._P146)
    elif ID_input=='147':
        print(PokeDex_details._P147)
    elif ID_input=='148':
        print(PokeDex_details._P148)
    elif ID_input=='149':
        print(PokeDex_details._P149)
    elif ID_input=='150':
        print(PokeDex_details._P150)
    elif ID_input=='151':
        print(PokeDex_details._P151)
    else:
        print("Please enter only Pokemon ID")
        print('\nPress Enter to continue')
        nonresponsive=input()
        print('Enter Pokemon ID: ')
        ID_input=input()
        pokemon_details_ID(ID_input)





















        
#ID_input=input()
#name_input=input()
#pokemon_details()

'''def getpokedex_details():
    print('To access info about Pokemon\n <A> Enter Pokemon name\n <B> Enter Pokemon ID number')
    pokemon_input=input()
    if pokemon_input=='A':
        print('Enter Pokemon Name: ')
        name_input=input()
        pokemon_details_name(name_input)
    if pokemon_input=='B':
        print('Enter Pokemon ID: ')
        ID_input=input()
        pokemon_details_ID(ID_input)


As=input()
def option_out():
    if As== 'C':
        getpokedex_details()

option_out()'''