# Harshit Goyal

_P001=('''
001 Bulbasaur
Type: Grass, Poison
Species: Seed Pokemon
Special Ability: Overgrow(Powers up Grass-type moves in a pinch.)
Hidden Ability: Chlorophyll(Boosts the Pokemon's Speed in sunshine.)
Description: A strange seed was planted on its back at birth. The plant sprouts and grows with this Pokémon.
''')

_P002=('''
002 Ivysaur
Type: Grass , Poison
Species: Seed Pokemon
Special Ability: Overgrow(Powers up Grass-type moves in a pinch.)
Hidden Ability: Chlorophyll(Boosts the Pokemon's Speed in sunshine.)
Description: When the bulb on its back grows large, it appears to lose the ability to stand on its hind legs.
''')

_P003=('''
003 Venasaur
Type: Grass, Poison
Species: Seed Pokemon
Special Ability: Overgrow(Powers up Grass-type moves in a pinch.)
Hidden Ability: Chlorophyll(Boosts the Pokemon's Speed in sunshine.)
Description: The plant blooms when it is absorbing solar energy. It stays on the move to seek sunlight.
''')

_P004=('''
004 Charmander
Type: Fire
Species: Lizard Pokemon
Special Ability: Blaze(Powers up Fire-type moves in a pinch.)
Hidden Ability: Solar Power(In sunshine, Sp.Atk is boosted but HP decreases.)
Description: Obviously prefers hot places. When it rains, steam is said to spout from the tip of its tail.
''')

_P005=('''
005 Charmeleon
Type: Fire
Species: Lizard Pokemon
Special Ability: Blaze(Powers up Fire-type moves in a pinch.)
Hidden Ability: Solar Power(In sunshine, Sp.Atk is boosted but HP decreases.)
Description: When it swings its burning tail, it elevates the temperature to unbearably high levels.
''')

_P006=('''
006 Charizard
Type: Fire, Flying
Species: Lizard Pokemon
Special Ability: Blaze(Powers up Fire-type moves in a pinch.)
Hidden Ability: Solar Power(In sunshine, Sp.Atk is boosted but HP decreases.)
Description: Spits fire that is hot enough to melt boulders. Known to cause forest fires unintentionally.
''')

_P007=('''
007 Squirtle
Type: Water
Species: Tiny Turtle Pokemon
Special Ability: Torrent(Powers up Water-type moves in a pinch.)
Hidden Ability: Rain Dish(The Pokemon gradually regains HP in rain.)
Description: After birth, its back swells and hardens into a shell. Powerfully sprays foam from its mouth.
''')

_P008=('''
008 Wartortle
Type: Water
Species: Turtle Pokemon
Special Ability: Torrent(Powers up Water-type moves in a pinch.)
Hidden Ability: Rain Dish(The Pokemon gradually regains HP in rain.)
Description: Often hides in water to stalk unwary prey. For swimming fast, it moves its ears to maintain balance.
''')

_P009=('''
009 Blastoise
Type: Water
Species: Shellfish Pokemon
Special Ability: Torrent(Powers up Water-type moves in a pinch.)
Hidden Ability: Rain Dish(The Pokemon gradually regains HP in rain.)
Description: A brutal POKéMON with pressurized water jets on its shell. They are used for high speed tackles.
''')

_P010=('''
010 Caterpie
Type: Bug
Species: Worm Pokemon
Special Ability: Shield Dust(Blocks the added effects of attacks taken.)
Hidden Ability: Run Away(Enable sure getaway from wild pokemon.)
Description: Its short feet are tipped with suction pads that enable it to tirelessly climb slopes and walls.
''')

_P011=('''
011 Metapod
Type: Bug
Species: Cocoon Pokemon
Special Ability: Shed Skin(The Pokemon may heeals its status condition.)
Hidden Ability: No hidden ability
Description: This POKEMON is vulnerable to attack while its shell is soft, exposing its weak and tender body.
''')

_P012=('''
012 Butterfree
Type: Bug, Flying
Species: Butterfly Pokémon
Special Ability: Compound Eyes(The Pokemon's accuracy is boosted.)
Hidden Ability: Tinted Lens(Powers up 'not very effective' moves.)
Description: In battle, it flaps its wings at high speed to release highly toxic dust into the air.
''')

_P013=('''
013 Weedle
Type: Bug, Poison
Species: Hairy Bug Pokémon
Special Ability: Shield Dust(Blocks the added effects of attacks taken.)
Hidden Ability: Run Away(Enable sure getaway from wild pokemon.)
Description: Often found in forests, eating leaves. It has a sharp venomous stinger on its head.
''')

_P014=('''
014 Kakuna
Type: Bug, Poison 
Species:  Cocoon Pokémon
Special Ability: Shed Skin(The Pokemon may heeals its status condition.)
Hidden Ability: No hidden ability
Description: Almost incapable of moving, this POKéMON can only harden its shell to protect itself from predators.
''')

_P015=('''
015 Beedril
Type: Bug, Poison 
Species: Poison Bee Pokémon
Special Ability: Swarm(Powers up Bug-type moves in a pinch.)
Hidden Ability: Sniper(Powers up moves if they become critical hits.)
Description: Flies at high speed and attacks using its large venomous stingers on its forelegs and tail.
''')

_P016=('''
016 Pidgey
Type: Normal, Flying
Species: Tiny Bird Pokémon
Special Ability: 1. Keen Eye(Prevents other Pokemon from lowering accuracy.)
                 2. Tangled Feet(Raises evasion if the Pokemon is confused.)
Hidden Ability: Big Pecks(Prevents the Pokemon from Defense-lowering attacks.)
Description: A common sight in forests and woods. It flaps its wings at ground level to kick up blinding sand.
''')

_P017=('''
017 Pidgeotto
Type: Normal, Flying
Species: Bird Pokémon
Special Ability: 1. Keen Eye(Prevents other Pokemon from lowering accuracy.)
                 2. Tangled Feet(Raises evasion if the Pokemon is confused.)
Hidden Ability: Big Pecks(Prevents the Pokemon from Defense-lowering attacks.)
Description: Very protective of its sprawling territorial area, this POKéMON will fiercely peck at any intruder.
''')

_P018=('''
018 Pidgeot
Type: Normal, Flying
Species: Bird Pokémon
Special Ability: 1. Keen Eye(Prevents other Pokemon from lowering accuracy.)
                 2. Tangled Feet(Raises evasion if the Pokemon is confused.)
Hidden Ability: Big Pecks(Prevents the Pokemon from Defense-lowering attacks.)
Description: When hunting, it skims the surface of water at high speed to pick off unwary prey such as MAGIKARP.
''')

_P019=('''
019 Rattata
Type: Normal
Species: Mouse Pokémon
Special Ability: 1. Run Away(Enable sure getaway from wild pokemon.)
                 2. Guts(Boosts Attack if there is status problem.)
Hidden Ability: Hustle(Boosts the Attack stats, but lower accuracy.)
Description: Bites anything when it attacks. Small and very quick, it is a common sight in many places.
''')

_P020=('''
020 Raticate
Type: Normal
Species: Mouse Pokémon
Special Ability: 1. Run Away(Enable sure getaway from wild pokemon.)
                 2. Guts(Boosts Attack if there is status problem.)
Hidden Ability: Hustle(Boosts the Attack stats, but lower accuracy.)
Description: It uses its whiskers to maintain its balance. It apparently slows down if they are cut off.
''')

_P021=('''
021 Spearow
Type: Normal, Flying
Species: Tiny Bird Pokémon
Special Ability: Keen Eye(Prevents other Pokemon from lowering accuracy.)
Hidden Ability: Sniper(Powers up moves if they become critical hits.)
Description: Eats bugs in grassy areas. It has to flap its short wings at high speed to stay airborne.
''')

_P022=('''
022 Fearow
Type: Normal, Flying
Species: Bird Pokémon
Special Ability: Keen Eye(Prevents other Pokemon from lowering accuracy.)
Hidden Ability: Sniper(Powers up moves if they become critical hits.)
Description: With its huge and magnificent wings, it can keep aloft without ever having to land for rest.
''')

_P023=('''
023 Ekans
Type: Poison
Species: Snake Pokémon
Special Ability: 1. Intimidate(Lowers te foe's Attack stats.)
                 2. Shed Skin(The Pokemon may heeals its status condition.)
Hidden Ability: Unnerve(Makes the foe nervous and unable to use Berries.)
Description: Moves silently and stealthily. Eats the eggs of birds, such as PIDGEY and SPEAROW, whole.
''')

_P024=('''
024 Arbok
Type: Poison
Species: Cobra Pokémon
Special Ability: 1. Intimidate(Lowers te foe's Attack stats.)
                 2. Shed Skin(The Pokemon may heeals its status condition.)
Hidden Ability: Unnerve(Makes the foe nervous and unable to use Berries.)
Description: It is rumored that the ferocious warning markings on its belly differ from area to area.
''')

_P025=('''
025 Pikachu
Type: Electric
Species: Mouse Pokémon
Special Ability: Static(Contact with the Pokemon may cause parslysis.)
Hidden Ability: Lightning Rod(Draws all Ekectric-type moves to up Sp.Attack.)
Description: When several of these POKéMON gather, their electricity could build and cause lightning storms.
''')

_P026=('''
026 Raichu
Type: Electric
Species: Mouse Pokémon
Special Ability: Static(Contact with the Pokemon may cause parslysis.)
Hidden Ability: Lightning Rod(Draws all Ekectric-type moves to up Sp.Attack.)
Description: Its long tail serves as a ground to protect itself from its own high voltage power.
''')

_P027=('''
027 Sandshrew
Type: Ground
Species: Mouse Pokémon
Special Ability: Sand Veil(Boosts the Pokémon's evasion in a sandstorm.)
Hidden Ability: Sand Rush(Boosts the Pokémon's Speed in a sandstorm.)
Description: Burrows deep underground in arid locations far from water. It only emerges to hunt for food.
''')

_P028=('''
028 Sandslash
Type: Ground
Species: Mouse Pokémon
Special Ability: Sand Veil(Boosts the Pokémon's evasion in a sandstorm.)
Hidden Ability: Sand Rush(Boosts the Pokémon's Speed in a sandstorm.)
Description: Curls up into a spiny ball when threatened. It can roll while curled up to attack or escape.
''')

_P029=('''
029 Nidoran_F
Type: Poison
Species: Poison Pin Pokémon
Special Ability: 1. Poison Point(Contact with the Pokémon may poison the attacker.)
                 2. Rivalry(Deals more damage to a Pokémon of same gender.)
Hidden Ability: Hustle(Boosts the Attack stats, but lower accuracy.)
Description: Although small, its venomous barbs render this POKéMON dangerous. The female has smaller horns.
''')

_P030=('''
030 Nidrina
Type: Poison
Species: Poison Pin Pokémon
Special Ability: 1. Poison Point(Contact with the Pokémon may poison the attacker.)
                 2. Rivalry(Deals more damage to a Pokémon of same gender.)
Hidden Ability: Hustle(Boosts the Attack stats, but lower accuracy.)
Description: The female's horn develops slowly. Prefers physical attacks such as clawing and biting.
''')

_P031=('''
031 Nidoqueen
Type: Poison, Ground
Species: Drill Pokémon
Special Ability: 1. Poison Point(Contact with the Pokémon may poison the attacker.)
                 2. Rivalry(Deals more damage to a Pokémon of same gender.)
Hidden Ability: Sheer Force(Removes added effects to increase move damage.)
Description: Its hard scales provide strong protection. It uses its hefty bulk to execute powerful moves.
''')

_P032=('''
032 Nidoran_M
Type: Poison
Species: Poison Pin Pokémon
Special Ability: 1. Poison Point(Contact with the Pokémon may poison the attacker.)
                 2. Rivalry(Deals more damage to a Pokémon of same gender.)
Hidden Ability: Hustle(Boosts the Attack stats, but lower accuracy.) 
Description: Stiffens its ears to sense danger. The larger its horns, the more powerful its secreted venom.
''')

_P033=('''
033 Nidrino
Type: Poison
Species: Poison Pin Pokémon
Special Ability: 1. Poison Point(Contact with the Pokémon may poison the attacker.)
                 2. Rivalry(Deals more damage to a Pokémon of same gender.)
Hidden Ability: Hustle(Boosts the Attack stats, but lower accuracy.)
Description: An aggressive POKéMON that is quick to attack. The horn on its head secretes a powerful venom.
''')

_P034=('''
034 Nidoking
Type: Poison, Ground
Species: Drill Pokémon
Special Ability: 1. Poison Point(Contact with the Pokémon may poison the attacker.)
                 2. Rivalry(Deals more damage to a Pokémon of same gender.)
Hidden Ability: Sheer Force(Removes added effects to increase move damage.)
Description: It uses its powerful tail in battle to smash, constrict, then break the prey’s bones.
''')

_P035=('''
035 Clefairy
Type: Fairy
Species: Fairy Pokémon
Special Ability: 1. Cute Charm(Contact with the Pokémon may cause infatuation.)
                 2. Magic Guard(The Pokémon only takes damage from attacks.)
Hidden Ability: Friend Guard(Reduces damage done to allies.)
Description: Its magical and cute appeal has many admirers. It is rare and found only in certain areas.
''')

_P036=('''
036 Clefable
Type: Fairy
Species: Fairy Pokémon
Special Ability: 1. Cute Charm(Contact with the Pokémon may cause infatuation.)
                 2. Magic Guard(The Pokémon only takes damage from attacks.)
Hidden Ability: Unaware(Ignores any stat changes in the Pokémon.)
Description: A timid fairy POKéMON that is rarely seen. It will run and hide the moment it senses people.
''')

_P037=('''
037 Vulpix
Type: Fire
Species: Fox Pokémon
Special Ability: Flash Fire(It powers up Fire-type moves if it's hit by one.)
Hidden Ability: Drought(Turns the sunlight harsh when the Pokémon enters a battle.)
Description: At the time of birth, it has just one tail. The tail splits from its tip as it grows older.
''')

_P038=('''
038 Ninetales
Type: Fire
Species: Fox Pokémon
Special Ability: Flash Fire(It powers up Fire-type moves if it's hit by one.)
Hidden Ability: Drought(Turns the sunlight harsh when the Pokémon enters a battle.)
Description: Very smart and very vengeful. Grabbing one of its many tails could result in a 1000-year curse.
''')

_P039=('''
039 Jigglypuff
Type: Normal, Fairy
Species: Balloon Pokémon
Special Ability: 1. Cute Charm(Contact with the Pokémon may cause infatuation.)
                 2.  Competitive(Sharply raises Sp.Atk when the Pokemon's stats are lowered.)
Hidden Ability: Friend Guard(Reduces damage done to allies.)
Description: When its huge eyes light up, it sings a mysteriously soothing melody that lulls its enemies to sleep.
''')

_P040=('''
040 Wigglytuff
Type: Normal, Fairy
Species: Balloon Pokémon
Special Ability:  1. Cute Charm(Contact with the Pokémon may cause infatuation.)
                  2.  Competitive(Sharply raises Sp.Atk when the Pokemon's stats are lowered.)
Hidden Ability: Frisk(The Pokémon can check an opposing Pokémon’s held item.)
Description: The body is soft and rubbery. When angered, it will suck in air and inflate itself to an enormous size.
''')

_P041=('''
041 Zubat
Type: Poison, Flying
Species: Bat Pokemon
Special Ability: Inner Focus(Protects the Pokémon from flinching.)
Hidden Ability: Infiltrator(Passes through the foe's barrier and strikes.)
Description: Forms colonies in perpetually dark places. Uses ultrasonic waves to identify and approach targets.
''')

_P042=('''
042 Golbat
Type: Poison, Flying
Species: Bat Pokemon
Special Ability: Inner Focus(Protects the Pokémon from flinching.)
Hidden Ability: Infiltrator(Passes through the foe's barrier and strikes.)
Description: Once it strikes, it will not stop draining energy from the victim even if it gets too heavy to fly.
''')

_P043=('''
043 Oddish
Type: Grass, Poison
Species: Weed Pokémon
Special Ability: Chlorophyll(Boosts the Pokemon's Speed in sunshine.)
Hidden Ability: Run Away(Enable sure getaway from wild pokemon.)
Description: During the day, it keeps its face buried in the ground. At night, it wanders around sowing its seeds.
''')

_P044=('''
044 Gloom
Type: Grass, Poison
Species: Weed Pokémon
Special Ability: Chlorophyll(Boosts the Pokemon's Speed in sunshine.)
Hidden Ability: Stench(The stench helps keep wild Pokémon away.)
Description: The fluid that oozes from its mouth isn’t drool. It is a nectar that is used to attract prey.
''')

_P045=('''
045 Vileplme
Type: Grass, Poison
Species: Weed Pokémon
Special Ability: Chlorophyll(Boosts the Pokemon's Speed in sunshine.)
Hidden Ability: Effect Spore(Contact may paralyze, poison, or cause sleep.)
Description: The larger its petals, the more toxic pollen it contains. Its big head is heavy and hard to hold up.
''')

_P046=('''
046 Paras
Type: Bug, Grass
Species: Mushroom Pokémon
Special Ability: 1. Effect Spore(Contact may paralyze, poison, or cause sleep.)
                 2.  Dry Skin(Restores HP in rain or when hit by Water-type moves. Reduces HP in sunshine, and increases the damage received from Fire-type moves.)
Hidden Ability: Damp(Prevents the use of self-destructing moves.)
Description: Burrows to suck tree roots. The mushrooms on its back grow by drawing nutrients from the bug host.
''')

_P047=('''
047 Parasect
Type: Bug, Grass
Species: Mushroom Pokémon
Special Ability: 1. Effect Spore(Contact may paralyze, poison, or cause sleep.)
                 2.  Dry Skin(Restores HP in rain or when hit by Water-type moves. Reduces HP in sunshine, and increases the damage received from Fire-type moves.)
Hidden Ability: Damp(Prevents the use of self-destructing moves.)
Description: A host-parasite pair in which the parasite mushroom has taken over the host bug. Prefers damp places.
''')

_P048=('''
048 Venonat
Type: Bug, Poison
Species: Insect Pokémon
Special Ability: 1. Compound Eyes(The Pokemon's accuracy is boosted.)
                 2. Tinted Lens(Powers up 'not very effective' moves.) 
Hidden Ability: Run Away(Enable sure getaway from wild pokemon.)
Description: Lives in the shadows of tall trees where it eats insects. It is attracted by light at night.
''')

_P049=('''
049 Venomoth
Type: Bug, Poison
Species: Poison Moth Pokémon
Special Ability: 1. Shield Dust(Blocks the added effects of attacks taken.)
                 2. Tinted Lens(Powers up 'not very effective' moves.)
Hidden Ability: Wonder Skin(Makes status moves more likely to miss.)
Description: The dust-like scales covering its wings are color coded to indicate the kinds of poison it has.
''')

_P050=('''
050 Diglett
Type: Ground
Species: Mole Pokémon
Special Ability: 1. Sand Veil(Boosts the Pokémon's evasion in a sandstorm.)
                 2. Arena Trap(Prevents opposing Pokémon from fleeing.)
Hidden Ability: Sand Force(Boosts the power of Rock-, Ground-, and Steel-type moves in a sandstorm.)
Description: Lives about one yard underground where it feeds on plant roots. It sometimes appears above ground.
''')

_P051=('''
051 Dugtrio
Type: Ground
Species:  Mole Pokémon
Special Ability: 1. Sand Veil(Boosts the Pokémon's evasion in a sandstorm.)
                 2. Arena Trap(Prevents opposing Pokémon from fleeing.)
Hidden Ability: Sand Force(Boosts the power of Rock-, Ground-, and Steel-type moves in a sandstorm.)
Description: A team of DIGLETT triplets. It triggers huge earthquakes by burrowing 60 miles underground.
''')

_P052=('''
052 Meowth
Type: Normal
Species: Scratch Cat Pokémon
Special Ability: 1. Pickup(The Pokémon may pick up the item an opposing Pokémon used during a battle. It may pick up items outside of battle, too.)
                 2. Technician(Powers up the Pokémon's weaker moves.)
Hidden Ability: Unnerve(Makes the foe nervous and unable to eat Berries.)
Description: Adores circular objects. Wanders the streets on a nightly basis to look for dropped loose change.
''')

_P053=('''
053 Persion
Type: Normal
Species: Classy Cat Pokémon
Special Ability: 1. Limber(The Pokémon is protected from paralysis.)
                 2. Technician(Powers up the Pokémon's weaker moves.)
Hidden Ability: Unnerve(Makes the foe nervous and unable to eat Berries.)
Description: Although its fur has many admirers, it is tough to raise as a pet because of its fickle meanness.
''')

_P054=('''
054 Psyduck
Type: Water
Species: Duck Pokémon
Special Ability: 1. Damp(Prevents the use of self-destructing moves.)
                 2. Cloud Nine(Eliminates the effects of weather.)
Hidden Ability: Swift Swim(Boosts the Pokémon's Speed in rain.)
Description: While lulling its enemies with its vacant look, this wily POKéMON will use psychokinetic powers.
''')

_P055=('''
055 Golduck
Type: Water
Species:  Duck Pokémon
Special Ability:  1. Damp(Prevents the use of self-destructing moves.)
                  2. Cloud Nine(Eliminates the effects of weather.)
Hidden Ability: Swift Swim(Boosts the Pokémon's Speed in rain.)
Description: Often seen swimming elegantly by lake shores. It is often mistaken for the Japanese monster, Kappa.
''')

_P056=('''
056 Mankey
Type: Fignting
Species: Pig Monkey Pokémon
Special Ability: 1. Vital Spirit(Prevents the Pokémon from falling asleep.)
                 2. Anger Point(Maxes the Attack stat after the Pokémon takes a critical hit.)
Hidden Ability: Defiant(Boosts the Pokémon's Attack stat when its stats are lowered.)
Description: Extremely quick to anger. It could be docile one moment then thrashing away the next instant.
''')

_P057=('''
057 Primeape
Type: Fignting
Species: Pig Monkey Pokémon
Special Ability: 1. Vital Spirit(Prevents the Pokémon from falling asleep.)
                 2. Anger Point(Maxes the Attack stat after the Pokémon takes a critical hit.)
Hidden Ability:  Defiant(Boosts the Pokémon's Attack stat when its stats are lowered.)
Description: Always furious and tenacious to boot. It will not abandon chasing its quarry until it is caught.
''')

_P058=('''
058 Growlithe
Type: Fire
Species: Puppy Pokémon
Special Ability: 1. Flash Fire(It powers up Fire-type moves if it's hit by one.)
                 2. Intimidate(Lowers te foe's Attack stats.)
Hidden Ability: Justified(Boosts the Attack stat when it's hit by a Dark-type move.)
Description: Very protective of its territory. It will bark and bite to repel intruders from its space.
''')

_P059=('''
059 Arcanine
Type: Fire
Species:  Legendary Pokémon
Special Ability: 1. Flash Fire(It powers up Fire-type moves if it's hit by one.)
                 2. Intimidate(Lowers te foe's Attack stats.)
Hidden Ability: Justified(Boosts the Attack stat when it's hit by a Dark-type move.)
Description: A POKéMON that has been admired since the past for its beauty. It runs agilely as if on wings.
''')

_P060=('''
060 Poliwag
Type: Water
Species: Tadpole Pokémon
Special Ability: 1. Water Absorb(Restores HP if hit by a Water-type move.)
                 2. Damp(Prevents the use of self-destructing moves.)
Hidden Ability: Swift Swim(Boosts the Pokémon's Speed in rain.)
Description: Its newly grown legs prevent it from running. It appears to prefer swimming than trying to stand.
''')

_P061=('''
061 Poliwhril
Type:  Water
Species: Tadpole Pokémon
Special Ability: 1. Water Absorb(Restores HP if hit by a Water-type move.)
                 2. Damp(Prevents the use of self-destructing moves.)
Hidden Ability: Swift Swim(Boosts the Pokémon's Speed in rain.)
Description: Capable of living in or out of water. When out of water, it sweats to keep its body slimy.
''')

_P062=('''
062 Poliwrath
Type: Water
Species: Tadpole Pokémon
Special Ability: 1. Water Absorb(Restores HP if hit by a Water-type move.)
                 2. Damp(Prevents the use of self-destructing moves.)
Hidden Ability: Swift Swim(Boosts the Pokémon's Speed in rain.)
Description: An adept swimmer at both the front crawl and breast stroke. Easily overtakes the best human swimmers.
''')

_P063=('''
063 Abra
Type: Psychic
Species: Psi Pokémon
Special Ability: 1. Synchronize(Passes poison, paralyze, or burn to the Pokémon that inflicted it.)
                 2. Inner Focus(Protects the Pokémon from flinching.)
Hidden Ability:  Magic Guard(The Pokémon only takes damage from attacks.)
Description: Using its ability to read minds, it will identify impending danger and TELEPORT to safety.
''')

_P064=('''
064 Kadabra
Type: Psychic
Species: Psi Pokémon
Special Ability: 1. Synchronize(Passes poison, paralyze, or burn to the Pokémon that inflicted it.)
                 2. Inner Focus(Protects the Pokémon from flinching.)
Hidden Ability:  Magic Guard(The Pokémon only takes damage from attacks.)
Description: It emits special alpha waves from its body that induce headaches just by being close by.
''')

_P065=('''
065 Alakazam
Type: Psychic
Species: Psi Pokémon
Special Ability: 1. Synchronize(Passes poison, paralyze, or burn to the Pokémon that inflicted it.)
                 2. Inner Focus(Protects the Pokémon from flinching.)
Hidden Ability:  Magic Guard(The Pokémon only takes damage from attacks.)
Description: Its brain can outperform a supercomputer. Its intelligence quotient is said to be 5,000.
''')

_P066=('''
066 Machop
Type: Fighting
Species: Superpower Pokémon
Special Ability: 2. Guts(Boosts Attack if there is status problem.)
                 2. No Guard(Ensures attacks by or against the Pokémon land.)
Hidden Ability: Steadfast(Boosts the Speed stat each time the Pokémon flinches.)
Description: Loves to build its muscles. It trains in all styles of martial arts to become even stronger.
''')

_P067=('''
06 Machoke
Type: Fighting
Species: Superpower Pokémon
Special Ability: 2. Guts(Boosts Attack if there is status problem.)
                 2. No Guard(Ensures attacks by or against the Pokémon land.)
Hidden Ability: Steadfast(Boosts the Speed stat each time the Pokémon flinches.)
Description: 
''')

_P068=('''
068 Machamp
Type: Fighting
Species: Superpower Pokémon
Special Ability: 2. Guts(Boosts Attack if there is status problem.)
                 2. No Guard(Ensures attacks by or against the Pokémon land.)
Hidden Ability: Steadfast(Boosts the Speed stat each time the Pokémon flinches.)
Description: Using its heavy muscles, it throws powerful punches that can send the victim clear over the horizon.Its muscular body is so powerful, it must wear a power save belt to be able to regulate its motions.
''')

_P069=('''
069 Bellsprout
Type: Grass, Poison
Species: Flower Pokémon
Special Ability: Chlorophyll(Boosts the Pokemon's Speed in sunshine.)
Hidden Ability: Gluttony(Makes the Pokémon use a held Berry earlier than usual.)
Description: A carnivorous POKéMON that traps and eats bugs. It uses its root feet to soak up needed moisture.
''')

_P070=('''
070 Weepinbell
Type: Grass, Poison
Species: Flycatcher Pokémon 
Special Ability: Chlorophyll(Boosts the Pokemon's Speed in sunshine.)
Hidden Ability: Gluttony(Makes the Pokémon use a held Berry earlier than usual.)
Description: It spits out POISONPOWDER to immobilize the enemy and then finishes it with a spray of ACID.
''')

_P071=('''
071 Victreebel
Type: Grass, Poison
Species: Flycatcher Pokémon
Special Ability: Chlorophyll(Boosts the Pokemon's Speed in sunshine.)
Hidden Ability: Gluttony(Makes the Pokémon use a held Berry earlier than usual.)
Description: Said to live in huge colonies deep in jungles, although no one has ever returned from there.
''')

_P072=('''
072 Tentacool
Type: Water, Poison
Species: Jellyfish Pokémon
Special Ability: 1. Clear Body(Prevents other Pokémon from lowering its stats.)
                 2. Liquid Ooze(Damages attackers using any draining move.)
Hidden Ability: Rain Dish(The Pokemon gradually regains HP in rain.)
Description: Drifts in shallow seas. Anglers who hook them by accident are often punished by its stinging acid.
''')

_P073=('''
073 Tentacruel
Type: Water, Poison
Species: Jellyfish Pokémon
Special Ability: 1. Clear Body(Prevents other Pokémon from lowering its stats.)
                 2. Liquid Ooze(Damages attackers using any draining move.)
Hidden Ability: Rain Dish(The Pokemon gradually regains HP in rain.)
Description: The tentacles are normally kept short. On hunts, they are extended to ensnare and immobilize prey.
''')

_P074=('''
074 Geodude
Type: Rock, Ground
Species: Rock Pokémon
Special Ability: 1. Rock Head(Protects the Pokémon from recoil damage.)
                 2. Sturdy(It cannot be knocked out with one hit.)
Hidden Ability: Sand Veil(Boosts the Pokémon's evasion in a sandstorm.)
Description: Found in fields and mountains. Mistaking them for boulders, people often step or trip on them.
''')

_P075=('''
075 Graveler
Type: Rock, Ground
Species: Rock Pokémon
Special Ability: 1. Rock Head(Protects the Pokémon from recoil damage.)
                 2. Sturdy(It cannot be knocked out with one hit.)
Hidden Ability: Sand Veil(Boosts the Pokémon's evasion in a sandstorm.)
Description: Rolls down slopes to move. It rolls over any obstacle without slowing or changing its direction.
''')

_P076=('''
076 Golem
Type: Rock, Ground
Species: Rock Pokémon
Special Ability: 1. Rock Head(Protects the Pokémon from recoil damage.)
                 2. Sturdy(It cannot be knocked out with one hit.)
Hidden Ability: Sand Veil(Boosts the Pokémon's evasion in a sandstorm.)
Description: Its boulder-like body is extremely hard. It can easily withstand dynamite blasts without damage.
''')

_P077=('''
077 Ponyta
Type: Fire
Species: Fire Horse Pokémon
Special Ability: 1. Run Away(Enable sure getaway from wild pokemon.)
                 2. Flash Fire(It powers up Fire-type moves if it's hit by one.)
Hidden Ability: Flame Body(Contact with the Pokémon may burn the attacker.)
Description: Its hooves are 10 times harder than diamonds. It can trample anything completely flat in little time.
''')

_P078=('''
078 Rapidash
Type: Fire
Species: Fire Horse Pokémon
Special Ability: 1. Run Away(Enable sure getaway from wild pokemon.)
                 2. Flash Fire(It powers up Fire-type moves if it's hit by one.)
Hidden Ability: Flame Body(Contact with the Pokémon may burn the attacker.)
Description: Very competitive, this POKéMON will chase anything that moves fast in the hopes of racing it.
''')

_P079=('''
089 Slowpoke
Type: Water, Psychic
Species:Dopey Pokémon 
Special Ability: 1. Oblivious(Keeps the Pokémon from being infatuated or falling for taunts.)
                 2. Own Tempo(Prevents the Pokémon from becoming confused.)
Hidden Ability: Regenerator(Restores a little HP when withdrawn from battle.)
Description: Incredibly slow and dopey. It takes 5 seconds for it to feel pain when under attack.
''')
_=P080=('''
080 Slowbro
Type: Water, Psychic
Species: Hermit Crab Pokémon
Special Ability: 1. Oblivious(Keeps the Pokémon from being infatuated or falling for taunts.)
                 2. Own Tempo(Prevents the Pokémon from becoming confused.)
Hidden Ability: Regenerator(Restores a little HP when withdrawn from battle.)
Description: The SHELLDER that is latched onto SLOWPOKE's tail is said to feed on the host’s left over scraps.
''')

_P081=('''
081 Magnemite
Type: Electric, Steel
Species: Magnet Pokémon
Special Ability: 1. Magnet Pull(Prevents Steel-type Pokémon from escaping.)
                 2. Sturdy(It cannot be knocked out with one hit.)
Hidden Ability: Analytic(Boosts move power when the Pokémon moves after the target.)
Description: Uses anti-gravity to stay suspended. Appears without warning and uses THUNDER WAVE and similar moves.
''')

_P082=('''
082 Magneton
Type: Electric, Steel
Species: Magnet Pokémon
Special Ability: 1. Magnet Pull(Prevents Steel-type Pokémon from escaping.)
                 2. Sturdy(It cannot be knocked out with one hit.)
Hidden Ability: Analytic(Boosts move power when the Pokémon moves after the target.)
Description: Formed by several MAGNEMITEs linked together. They frequently appear when sunspots flare up.
''')

_P083=('''
083 Farfetch'd
Type: Normal, Fighting
Species: Wild Duck Pokémon
Special Ability: 1. Keen Eye(Prevents other Pokemon from lowering accuracy.)
                 2. Inner Focus(Protects the Pokémon from flinching.)
Hidden Ability: Defiant(Boosts the Pokémon's Attack stat when its stats are lowered.)
Description: The sprig of green onions it holds is its weapon. It is used much like a metal sword.
''')

_P084=('''
084 Doduo
Type: Normal, Flying
Species: Twin Bird Pokémon
Special Ability: 1. Run Away(Enable sure getaway from wild pokemon.)
                 2. Early Bird(The Pokémon awakens quickly from sleep.)
Hidden Ability: Tangled Feet(Raises evasion if the Pokemon is confused.)
Description: A bird that makes up for its poor flying with its fast foot speed. Leaves giant footprints.
''')

_P085=('''
085 Dodrio
Type: Normal, Flying
Species: Triple Bird Pokémon
Special Ability: 1. Run Away(Enable sure getaway from wild pokemon.)
                 2. Early Bird(The Pokémon awakens quickly from sleep.)
Hidden Ability: Tangled Feet(Raises evasion if the Pokemon is confused.)
Description: Uses its three brains to execute complex plans. While two heads sleep, one head stays awake.
''')

_P086=('''
086 Seel
Type: Water
Species: Sea Lion Pokémon
Special Ability: 1. Thick Fat(Boosts resistance to Fire- and Ice-type moves.)
                 2. Hydration(Heals status problems if it is raining.)
Hidden Ability: Ice Body(The Pokémon gradually regains HP in a hailstorm.)
Description: The protruding horn on its head is very hard. It is used for bashing through thick ice.
''')

_P087=('''
087 Dewgong
Type: Water, Ice
Species: Sea Lion Pokémon
Special Ability: 1. Thick Fat(Boosts resistance to Fire- and Ice-type moves.)
                 2. Hydration(Heals status problems if it is raining.)
Hidden Ability: Ice Body(The Pokémon gradually regains HP in a hailstorm.)
Description: Stores thermal energy in its body. Swims at a steady 8 knots even in intensely cold waters.
''')

_P088=('''
088 Grimer
Type: Poison
Species: Sludge Pokémon
Special Ability: 1. Stench(The stench may cause the target to flinch.)
                 2. Sticky Hold(Protects the Pokémon from item theft.)
Hidden Ability: Poison Touch(May poison a target when the Pokémon makes contact.)
Description: Appears in filthy areas. Thrives by sucking up polluted sludge that is pumped out of factories.
''')

_P089=('''
089 Muk
Type: Poison
Species: Sludge Pokémon
Special Ability: 1. Stench(The stench may cause the target to flinch.)
                 2. Sticky Hold(Protects the Pokémon from item theft.)
Hidden Ability: Poison Touch(May poison a target when the Pokémon makes contact.)
Description: Thickly covered with a filthy, vile sludge. It is so toxic, even its footprints contain poison.
''')

_P090=('''
090 Shellder
Type: Water
Species: Bivalve Pokémon
Special Ability: 1. Shell Armor(Protects the Pokémon from critical hits.)
                 2. Skill Link(Increases the number of times multi-strike moves hit.)
Hidden Ability: Overcoat(Protects the Pokémon from things like sand, hail, and powder.)
Description: Its hard shell repels any kind of attack. It is vulnerable only when its shell is open.
''')

_P091=('''
091 Cloyster
Type: Water, Ice
Species: Bivalve Pokémon
Special Ability: 1. Shell Armor(Protects the Pokémon from critical hits.)
                 2. Skill Link(Increases the number of times multi-strike moves hit.)
Hidden Ability: Overcoat(Protects the Pokémon from things like sand, hail, and powder.)
Description: When attacked, it launches its horns in quick volleys. Its innards have never been seen.
''')

_P092=('''
092 Gastly
Type: Ghost, Poison
Species: Gas Pokémon
Special Ability: Levitate(By floating in the air, the Pokémon receives full immunity to all Ground-type moves.)
Hidden Ability: No Hidden Ability
Description: Almost invisible, this gaseous POKéMON cloaks the target and puts it to sleep without notice.
''')

_P093=('''
093 Haunter
Type: Ghost, Poison
Species: Gas Pokémon
Special Ability: Levitate(By floating in the air, the Pokémon receives full immunity to all Ground-type moves.)
Hidden Ability: No Hidden Ability
Description: Because of its ability to slip through block walls, it is said to be from another dimension.
''')

_P094=('''
094 Ganger
Type: Ghost, Poison
Species: Shadow Pokémon
Special Ability: Cursed Body(May disable a move used on the Pokémon.)
Hidden Ability: No Hidden Ability
Description: Under a full moon, this POKéMON likes to mimic the shadows of people and laugh at their fright.
''')

_P095=('''
095 Onix
Type: Rock, Ground 
Species: Rock Snake Pokemon
Special Ability: 1. Rock Head(Protects the Pokémon from recoil damage.)
                 2. Sturdy(It cannot be knocked out with one hit.)
Hidden Ability: Weak Armor(Physical attacks lower its Defense stat and raise its Speed stat.)
Description: As it grows, the stone portions of its body harden to become similar to a diamond, but colored black.
''')

_P096=('''
096 Drowzee
Type:Psychic 
Species: Hypnosis Pokémon
Special Ability: 1. Insomnia(Prevents the Pokémon from falling asleep.)
                 2. Forewarn(Determines what moves an opposing Pokémon has.)
Hidden Ability: Inner Focus(Protects the Pokémon from flinching.)
Description: Puts enemies to sleep then eats their dreams. Occasionally gets sick from eating bad dreams.
''')

_P097=('''
097 Hypno
Type: Psychic 
Species: Hypnosis Pokémon
Special Ability: 1. Insomnia(Prevents the Pokémon from falling asleep.)
                 2. Forewarn(Determines what moves an opposing Pokémon has.)
Hidden Ability: Inner Focus(Protects the Pokémon from flinching.)
Description: When it locks eyes with an enemy, it will use a mix of PSI moves such as HYPNOSIS and CONFUSION.
''')

_P098=('''
098 Krabby
Type: Water
Species: River Crab Pokémon
Special Ability: 1. Hyper Cutter(Prevents other Pokémon from lowering its Attack stat.)
                 2. Shell Armor(Protects the Pokémon from critical hits.)
Hidden Ability: Sheer Force(Removes additional effects to increase move damage.)
Description: Its pincers are not only powerful weapons, they are used for balance when walking sideways.
''')

_P099=('''
099 Kingler
Type: Water
Species: Pincer Pokémon
Special Ability: 1. Hyper Cutter(Prevents other Pokémon from lowering its Attack stat.)
                 2. Shell Armor(Protects the Pokémon from critical hits.)
Hidden Ability: Sheer Force(Removes additional effects to increase move damage.)
Description: The large pincer has 10000 hp of crushing power. However, its huge size makes it unwieldy to use.
''')

_P100=('''
100 Voltorb
Type: Electric
Species: Ball Pokémon
Special Ability: 1. Soundproof(Gives full immunity to all sound-based moves.)
                 2. Static(Contact with the Pokémon may cause paralysis.)
Hidden Ability: Aftermath(Damages the attacker if it contacts the Pokémon with a finishing hit.)
Description: Usually found in power plants. Easily mistaken for a POKé BALL, they have zapped many people.
''')

_P101=('''
101 Electode
Type: Electric
Species: Ball Pokémon
Special Ability: 1. Soundproof(Gives full immunity to all sound-based moves.)
                 2. Static(Contact with the Pokémon may cause paralysis.)
Hidden Ability: Aftermath(Damages the attacker if it contacts the Pokémon with a finishing hit.)
Description: It stores electric energy under very high pressure. It often explodes with little or no provocation.
''')

_P102=('''
102 Exeggcute
Type: Grass, Psychic
Species: Egg Pokémon
Special Ability: Chlorophyll(Boosts the Pokemon's Speed in sunshine.)
Hidden Ability: Harvest(May create another Berry after one is used.)
Description: Often mistaken for eggs. When disturbed, they quickly gather and attack in swarms.
''')

_P103=('''
103 Exeggutor
Type: Grass, Psychic
Species: Coconut Pokémon
Special Ability: Chlorophyll(Boosts the Pokemon's Speed in sunshine.)
Hidden Ability: Harvest(May create another Berry after one is used.)
Description: Legend has it that on rare occasions, one of its heads will drop off and continue on as an EXEGGCUTE.
''')

_P104=('''
104 Cubone
Type: Ground
Species: Lonely Pokémon
Special Ability: 1. Rock Head(Protects the Pokémon from recoil damage.)
                 2. Lightning Rod(Draws all Ekectric-type moves to up Sp.Attack.)
Hidden Ability: Battle Armor(Protects the Pokémon from critical hits.)
Description: Because it never removes its skull helmet, no one has ever seen this POKéMON’s real face.
''')

_P105=('''
105 Marowak
Type: Ground
Species: Bone Keeper Pokémon
Special Ability: 1. Rock Head(Protects the Pokémon from recoil damage.)
                 2. Lightning Rod(Draws all Ekectric-type moves to up Sp.Attack.)
Hidden Ability: Battle Armor(Protects the Pokémon from critical hits.)
Description: The bone it holds is its key weapon. It throws the bone skillfully like a boomerang to KO targets.
''')

_P106=('''
106 Hitmonlee
Type: Fighting
Species: Kicking Pokémon
Special Ability: 1. Limber(Protects the Pokémon from paralysis.)
                 2. Reckless(Powers up moves that have recoil damage.)
Hidden Ability: Unburden(Boosts the Speed stat if its held item is used or lost.)
Description: When in a hurry, its legs lengthen progressively. It runs smoothly with extra long, loping strides.
''')

_P107=('''
107 Hitmonchan
Type: Fighting
Species: Punching Pokémon
Special Ability: 1. Keen Eye(Prevents other Pokemon from lowering accuracy.)
                 2. Iron Fist(Powers up punching moves.)
Hidden Ability: Inner Focus(Protects the Pokémon from flinching.)
Description: While apparently doing nothing, it fires punches in lightning fast volleys that are impossible to see.
''')

_P108=('''
108 Lickitung
Type: Normal
Species: Licking Pokémon
Special Ability: 1. Oblivious(Keeps the Pokémon from being infatuated or falling for taunts.)
                 2. Own Tempo(Prevents the Pokémon from becoming confused.)
Hidden Ability: Cloud Nine(Eliminates the effects of weather.)
Description: Its tongue can be extended like a chameleon’s. It leaves a tingling sensation when it licks enemies.
''')

_P109=('''
109 Koffing
Type: Poison
Species: Poison Gas Pokémon
Special Ability: 1. Levitate(By floating in the air, the Pokémon receives full immunity to all Ground-type moves.)
                 2. Neutralizing Gas(If the Pokémon with Neutralizing Gas is in the battle, the effects of all Pokémon’s Abilities will be nullified or will not be triggered.)
Hidden Ability: Stench(The stench may cause the target to flinch.)
Description: Because it stores several kinds of toxic gases in its body, it is prone to exploding without warning.
''')

_P110=('''
110 Weezing
Type: Poison
Species: Poison Gas Pokémon
Special Ability: 1. Levitate(By floating in the air, the Pokémon receives full immunity to all Ground-type moves.)
                 2. Neutralizing Gas(If the Pokémon with Neutralizing Gas is in the battle, the effects of all Pokémon’s Abilities will be nullified or will not be triggered.)
Hidden Ability: Stench(The stench may cause the target to flinch.)
Description: Where two kinds of poison gases meet, 2 KOFFINGs can fuse into a WEEZING over many years.
''')

_P111=('''
111 Rhyhorn
Type: Ground, Rock
Species: Spikes Pokémon
Special Ability: 1. Rock Head(Protects the Pokémon from recoil damage.)
                 2. Lightning Rod(Draws all Ekectric-type moves to up Sp.Attack.)
Hidden Ability: Reckless(Powers up moves that have recoil damage.) 
Description: Its massive bones are 1000 times harder than human bones. It can easily knock a trailer flying.
''')

_P112=('''
112 Rhydon
Type: Ground, Rock
Species: Drill Pokémon
Special Ability: 1. Rock Head(Protects the Pokémon from recoil damage.)
                 2. Lightning Rod(Draws all Ekectric-type moves to up Sp.Attack.)
Hidden Ability: Reckless(Powers up moves that have recoil damage.)
Description: Protected by an armor-like hide, it is capable of living in molten lava of 3,600 degrees.
''')

_P113=('''
113 Chansey
Type: Normal
Species: Egg Pokémon
Special Ability: 1. Natural Cure(All status conditions heal when the Pokémon switches out.)
                 2. Serene Grace(Boosts the likelihood of additional effects occurring when attacking.)
Hidden Ability: Healer(Sometimes heals an ally's status condition.)
Description: A rare and elusive POKéMON that is said to bring happiness to those who manage to get it.
''')

_P114=('''
114 Tangela
Type: Grass
Species: Vine Pokémon
Special Ability: 1. Chlorophyll(Boosts the Pokémon's Speed stat in sunshine.)
                 2. Leaf Guard(Prevents status conditions in sunny weather.)
Hidden Ability: Regenerator(Restores a little HP when withdrawn from battle.)
Description: The whole body is swathed with wide vines that are similar to seaweed. Its vines shake as it walks.
''')

_P115=('''
115 Kangaskhan
Type: Normal
Species: Parent Pokémon
Special Ability: 1. Early Bird(The Pokémon awakens quickly from sleep.)
                 2. Scrappy(Makes Normal- and Fighting-type moves hit Ghost-type Pokémon.)
Hidden Ability: Inner Focus(Protects the Pokémon from flinching.)
Description: The infant rarely ventures out of its mother’s protective pouch until it is 3 years old.
''')

_P116=('''
116 Horsea
Type: Water
Species: Dragon Pokémon
Special Ability: 1. Swift Swim(Boosts the Pokémon's Speed in rain.)
                 2. Sniper(Powers up moves if they become critical hits.)
Hidden Ability: Damp(Prevents the use of self-destructing moves.)
Description: Known to shoot down flying bugs with precision blasts of ink from the surface of the water.
''')

_P117=('''
117 Seadra
Type: Water
Species: Dragon Pokémon
Special Ability: 1. Poison Point(Contact with the Pokémon may poison the attacker.)
                 2. Sniper(Powers up moves if they become critical hits.)
Hidden Ability: Damp(Prevents the use of self-destructing moves.)
Description: Capable of swimming backwards by rapidly flapping its wing-like pectoral fins and stout tail.
''')

_P118=('''
118 Goldeen
Type: Water
Species: Goldfish Pokémon
Special Ability: 1. Swift Swim(Boosts the Pokémon's Speed in rain.)
                 2. Water Veil(Prevents the Pokémon from getting a burn.)
Hidden Ability: Lightning Rod(Draws all Ekectric-type moves to up Sp.Attack.)
Description: Its tail fin billows like an elegant ballroom dress, giving it the nickname of the Water Queen.
''')

_P119=('''
119 Seaking
Type: Water
Species: Goldfish Pokémon
Special Ability: 1. Swift Swim(Boosts the Pokémon's Speed in rain.)
                 2. Water Veil(Prevents the Pokémon from getting a burn.)
Hidden Ability: Lightning Rod(Draws all Ekectric-type moves to up Sp.Attack.)
Description: In the autumn spawning season, they can be seen swimming powerfully up rivers and creeks.
''')

_P120=('''
120 Staryu
Type: Water
Species: Star Shape Pokémon
Special Ability: 1. Illuminate(Raises the likelihood of meeting wild Pokémon.)
                 2. Natural Cure(All status conditions heal when the Pokémon switches out.)
Hidden Ability: Analytic(Boosts move power when the Pokémon moves after the target.)
Description: An enigmatic POKéMON that can effortlessly regenerate any appendage it loses in battle.
''')

_P121=('''
121 Starmie
Type: Water, Psychic
Species: Mysterious Pokémon
Special Ability: 1. Illuminate(Raises the likelihood of meeting wild Pokémon.)
                 2. Natural Cure(All status conditions heal when the Pokémon switches out.)
Hidden Ability: Analytic(Boosts move power when the Pokémon moves after the target.)
Description: Its central core glows with the seven colors of the rainbow. Some people value the core as a gem.
''')

_P122=('''
122 Mr. Mime
Type: Psychic, Fairy
Species: Barrier Pokémon
Special Ability: 1. Soundproof(Gives full immunity to all sound-based moves.)
                 2. Filter(Reduces damage from supereffective attacks.)
Hidden Ability: Technician(Powers up the Pokémon's weaker moves.)
Description: If interrupted while it is miming, it will slap around the offender with its broad hands.
''')

_P123=('''
123 Scyther
Type: Bug, Flying
Species: Mantis Pokémon
Special Ability: 1. Technician(Powers up the Pokémon's weaker moves.)
                 2. Swarm(Powers up Bug-type moves in a pinch.)
Hidden Ability: Steadfast(Boosts the Speed stat each time the Pokémon flinches.)
Description: With ninja-like agility and speed, it can create the illusion that there is more than one.
''')

_P124=('''
124 Jynx
Type: Psychic, Ice
Species: Human Shape Pokémon
Special Ability: 1. Oblivious(Keeps the Pokémon from being infatuated or falling for taunts.)
                 2. Forewarn(Determines what moves an opposing Pokémon has.)
Hidden Ability: Dry Skin(Reduces HP if it's hot. Water restores HP.)
Description: It seductively wiggles its hips as it walks. It can cause people to dance in unison with it.
''')

_P125=('''
125 Electabuzz
Type: Electric
Species: Electric Pokémon
Special Ability: Static(Contact with the Pokémon may cause paralysis.)
Hidden Ability: Vital Spirit(Prevents the Pokémon from falling asleep.)
Description: Normally found near power plants, they can wander away and cause major blackouts in cities.
''')

_P126=('''
126 MAgmar
Type: Fire
Species: Spitfire Pokémon
Special Ability: Flame Body(Contact with the Pokémon may burn the attacker.)
Hidden Ability: Vital Spirit(Prevents the Pokémon from falling asleep.)
Description: Its body always burns with an orange glow that enables it to hide perfectly among flames.
''')

_P127=('''
127 Pinsir
Type: Bug
Species: Stag Beetle Pokémon
Special Ability: 1. Hyper Cutter(Prevents other Pokémon from lowering its Attack stat.)
                 2. Mold Breaker(Moves can be used on the target regardless of its Abilities.)
Hidden Ability: Moxie(Boosts the Attack stat after knocking out any Pokémon.)
Description: If it fails to crush the victim in its pincers, it will swing it around and toss it hard.
''')

_P128=('''
128 Tauros
Type: Normal
Species: Wild Bull Pokémon
Special Ability: 1. Intimidate(Lowers the opposing Pokémon's Attack stat.)
                 2. Anger Point(Maxes the Attack stat after the Pokémon takes a critical hit.)
Hidden Ability: Sheer Force(Removes additional effects to increase move damage.)
Description: 
''')

_P129=('''
129 Magikarp
Type: Water
Species: Fish Pokémon
Special Ability: Swift Swim(Boosts the Pokémon's Speed stat in rain.)
Hidden Ability: Rattled(Some move types scare it and boost its Speed stat.)
Description: In the distant past, it was somewhat stronger than the horribly weak descendants that exist today.
''')

_P130=('''
130 Gyrados
Type: Water, Flying
Species: Atrocious Pokémon
Special Ability: Intimidate(Lowers the opposing Pokémon's Attack stat.)
Hidden Ability: Moxie(Boosts the Attack stat after knocking out any Pokémon.)
Description: 	Rarely seen in the wild. Huge and vicious, it is capable of destroying entire cities in a rage.
''')

_P131=('''
131 Lapras
Type: Water, Ice
Species: Transport Pokémon
Special Ability: 1. Water Absorb(Restores HP if hit by a Water-type move.)
                 2. Shell Armor(Protects the Pokémon from critical hits.)
Hidden Ability: Hydration(Heals status conditions if it's raining.)
Description: A POKéMON that has been overhunted almost to extinction. It can ferry people across the water.
''')

_P132=('''
132 Ditto
Type: Normal
Species: Transform Pokémon
Special Ability: Limber(Protects the Pokémon from paralysis.)
Hidden Ability: Imposter(The Pokémon transforms itself into the Pokémon it's facing.)
Description: Capable of copying an enemy’s genetic code to instantly transform itself into a duplicate of the enemy.
''')

_P133=('''
133 Eevee
Type: Normal
Species: Evolution Pokémon
Special Ability: 1. Run Away(Enables a sure getaway from wild Pokémon.)
                 2. Adaptability(Powers up moves of the same type as the Pokémon.)
Hidden Ability: Anticipation(Senses an opposing Pokémon's dangerous moves.)
Description: Its genetic code is irregular. It may mutate if it is exposed to radiation from element STONEs.
''')

_P134=('''
134 Vaporeon
Type: Water
Species: Bubble Jet Pokémon
Special Ability: Water Absorb(Restores HP if hit by a Water-type move.)
Hidden Ability: Hydration(Heals status conditions if it's raining.)
Description: 	Lives close to water. Its long tail is ridged with a fin which is often mistaken for a mermaid’s.
''')

_P135=('''
135 Jolteon
Type: Electric
Species: Lightning Pokémon
Special Ability: Volt Absorb(Restores HP if hit by an Electric-type move.)
Hidden Ability:Quick Feet(Boosts the Speed stat if the Pokémon has a status condition.)
Description: It accumulates negative ions in the atmosphere to blast out 10000-volt lightning bolts.
''')

_P136=('''
136 Flareon
Type: Fire
Species: Flame Pokémon
Special Ability: Flash Fire(It powers up Fire-type moves if it's hit by one.)
Hidden Ability: Guts(Boosts Attack if there is status problem.)
Description: When storing thermal energy in its body, its temperature could soar to over 1600 degrees.
''')

_P137=('''
137 Porygon
Type: Normal
Species: Virtual Pokémon
Special Ability: 1. Trace(The Pokémon copies an opposing Pokémo's Ability.)
                 2. Download(Adjusts power based on an opposing Pokémon's stats.)
Hidden Ability: Analytic(Boosts move power when the Pokémon moves after the target.)
Description: A POKéMON that consists entirely of programming code. Capable of moving freely in cyberspace.
''')

_P138=('''
138 Omanyte
Type: Water, Rock
Species: Spiral Pokémon
Special Ability: 1. Swift Swim(Boosts the Pokémon's Speed stat in rain.)
                 2. Shell Armor(Protects the Pokémon from critical hits.)
Hidden Ability: Weak Armor(Physical attacks lower its Defense stat and raise its Speed stat.)
Description: Although long extinct, in rare cases, it can be genetically resurrected from fossils.
''')

_P139=('''
139 Omastar
Type: Water, Rock
Species: Spiral Pokémon
Special Ability: 1. Swift Swim(Boosts the Pokémon's Speed stat in rain.)
                 2. Shell Armor(Protects the Pokémon from critical hits.)
Hidden Ability: Weak Armor(Physical attacks lower its Defense stat and raise its Speed stat.)
Description: A prehistoric POKéMON that died out when its heavy shell made it impossible to catch prey.
''')

_P140=('''
140 Kabuto
Type: Water, Rock
Species: Shellfish Pokémon
Special Ability: 1. Swift Swim(Boosts the Pokémon's Speed stat in rain.)
                 2. Battle Armor(Protects the Pokémon from critical hits.)
Hidden Ability: Weak Armor(Physical attacks lower its Defense stat and raise its Speed stat.)
Description: A POKéMON that was resurrected from a fossil found in what was once the ocean floor eons ago.
''')

_P141=('''
141 
Type: Water, Rock
Species: Shellfish Pokémon
Special Ability: 1. Swift Swim(Boosts the Pokémon's Speed stat in rain.)
                 2. Battle Armor(Protects the Pokémon from critical hits.)
Hidden Ability: Weak Armor(Physical attacks lower its Defense stat and raise its Speed stat.)
Description: Its sleek shape is perfect for swimming. It slashes prey with its claws and drains the body fluids.
''')

_P142=('''
142 Aerodactyl
Type: Rock, Flying
Species: Fossil Pokémon
Special Ability: 1. Rock Head(Protects the Pokémon from recoil damage.)
                 2. Pressure (Protects the Pokémon from recoil damage.)
Hidden Ability: Unnerve(Makes the foe nervous and unable to eat Berries.)
Description: A ferocious, prehistoric POKéMON that goes for the enemy's throat with its serrated saw-like fangs.
''')

_P143=('''
143 Snorlax
Type: Normal
Species: Sleeping Pokémon
Special Ability: 1. Immunity(Prevents the Pokémon from getting poisoned.)
                 2. Thick Fat(Boosts resistance to Fire- and Ice-type moves.)
Hidden Ability: Gluttony(Makes the Pokémon use a held Berry earlier than usual.)
Description: Very lazy. Just eats and sleeps. As its rotund bulk builds, it becomes steadily more slothful.
''')

_P144=('''
144 Articuno
Type: Ice, Flying
Species: Freeze Pokémon
Special Ability: Pressure (Protects the Pokémon from recoil damage.)
Hidden Ability: Snow Cloak(Boosts evasion in a hailstorm.)
Description: A legendary bird POKéMON that is said to appear to doomed people who are lost in icy mountains.
''')

_P145=('''
145 Zapdos
Type: Electric, Flying
Species: Electric Pokémon
Special Ability:Pressure (Protects the Pokémon from recoil damage.) 
Hidden Ability: Static(Contact with the Pokémon may cause paralysis.)
Description: A legendary bird POKéMON that is said to appear from clouds while dropping enormous lightning bolts.
''')

_P146=('''
146 Moltress
Type: Fire, Flying
Species: Flame Pokémon
Special Ability: Pressure (Protects the Pokémon from recoil damage.)
Hidden Ability: Flame Body(Contact with the Pokémon may burn the attacker.)
Description: Known as the legendary bird of fire. Every flap of its wings creates a dazzling flash of flames.
''')

_P147=('''
147 Dratini
Type: Dragon
Species: Dragon Pokémon
Special Ability:  Shed Skin(The Pokémon may heal its own status conditions.)
Hidden Ability: Marvel Scale(Boosts the Defense stat if the Pokémon has a status condition.)
Description: Long considered a mythical POKéMON until recently when a small colony was found living underwater.
''')

_P148=('''
148 Dragonair
Type: Dragon
Species: Dragon Pokémon
Special Ability: Shed Skin(The Pokémon may heal its own status conditions.)
Hidden Ability: Marvel Scale(Boosts the Defense stat if the Pokémon has a status condition.)
Description: A mystical POKéMON that exudes a gentle aura. Has the ability to change climate conditions.
''')

_P149=('''
149 Dragonaite
Type: Dragon, Flying
Species: Dragon Pokémon
Special Ability: Inner Focus(Protects the Pokémon from flinching.)
Hidden Ability: Multiscale(Reduces damage the Pokémon takes when its HP is full.)
Description: An extremely rarely seen marine POKéMON. Its intelligence is said to match that of humans.
''')

_P150=('''
150 Mewtwo
Type: Psychic
Species: Genetic Pokémon
Special Ability: Pressure (Protects the Pokémon from recoil damage.)
Hidden Ability: Unnerve(Makes the foe nervous and unable to eat Berries.)
Description: It was created by a scientist after years of horrific gene splicing and DNA engineering experiments.
''')

_P151=('''
151 Mew
Type: Psychic
Species: New Species Pokémon
Special Ability: Synchronize(Passes poison, paralyze, or burn to the Pokémon that inflicted it.)
Hidden Ability: No hidden Ability
Description: A MEW is said to possess the genes of all POKéMON.Because it can use all kinds of moves, many scientists believe MEW to be the ancestor of Pokémon.
''')

#pokemon_details()