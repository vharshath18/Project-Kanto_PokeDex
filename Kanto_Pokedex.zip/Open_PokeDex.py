import PokeDex
#PPD=PokeDex.Pokedex
#print(PPD)
def pokedex_title():
    return ('PokeDex_Kanto_Region')
def pokedex_table_row_headings():
    return ('Ndex  Pokémon')
def pokedex_table_contents():
    i=0
    j=0
    PDex=[]
    for i in PokeDex.Pokedex:
        a=('#{} - {}'.format(i,PokeDex.Pokedex[i]))
        PDex.append(a)
        #i+=1
    def open_pokemons():
        for j in range(0,151):
            A=PDex.__getitem__(j)
            print(A)
            j+=1
    return open_pokemons()
        
    
    

#pokedex_title()
#pokedex_table_row_headings()
#pokedex_table_contents()